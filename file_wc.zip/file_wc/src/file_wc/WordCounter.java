// Dinesh Panjwani
//  508 728 8347
// dp.itprof@gmail.com


package file_wc;
import java.io.*;
import java.util.*;

public class WordCounter {
  
  static TreeMap <String, Integer > hmWordList =new TreeMap<String, Integer>(); 
  static List<Integer> iUniqueWordInTweets = new ArrayList<Integer>();
  
  public static void main(String[] args) {
		
		String inFileName="tweet_input\\tweets.txt";
		String outFileNameWords="tweet_output\\ft1.txt";
		String outFileNameStats="tweet_output\\ft2.txt";
		String outFileNameCount="tweet_output\\ft3_uniquecounts.txt";
		
		FileReader inFile;
		FileWriter outFileWC;
		FileWriter outFileStats, outFileCounts;
		
		String sFileLine;
		int iRecCount=0;
		int iRecUnique=0;
		float iMedian=0;
		String sSpaceString="                                                                                                                                  "; // used for Padding
		//above used for padding
		try {
			if (!args[0].isEmpty()) {
				inFileName =args[0] ; 
				}
			if (!args[1].isEmpty()) {
				outFileNameWords =args[1] ; 
				}
			if (!args[2].isEmpty()) {
				outFileNameStats =args[2] ; 
				}
			
		}catch (Exception e) {
			 System.out.println("File Name Issue " + e.getMessage()  );
			}
				
		
		
		System.out.println("Start \n-----------------------------------------------------"); 
		
// Open Files	
	 try { 
		 System.out.println("-----Opening Files----" );
		 inFile = new  FileReader(inFileName); 
		 outFileWC = new FileWriter(outFileNameWords);
		 outFileStats = new FileWriter(outFileNameStats);
		 //outFileCounts = new FileWriter(outFileNameCount);
			    } catch(Exception e) { 
	      System.out.println("*************Cannot Open File: " + e.getMessage()  );
	      return; 
	    }

// Read File	 	 
	 try{
		 System.out.println("-----Starting to Read File -----\n" );
          BufferedReader bufferReader = new BufferedReader(inFile);
          while ((sFileLine = bufferReader.readLine()) != null)   {
        	       iRecCount++;
         	       // Tokenize        
        	       iRecUnique=TokenizeLine(sFileLine,iRecCount);
                  iUniqueWordInTweets.add(iRecUnique) ; //  the number of unique ones in the record
                  
                  // Calculate Median 
                  try{
    		 		iMedian=MedianCalc();
    		 		outFileStats.write( iMedian + String.format("%n")); // 
    		 	   }
    		 	 catch (Exception e){
    		         System.out.println("*************Error writing Stats: " + e.getMessage());                      
    		       }
                  
                  
          }
          bufferReader.close();
	      }catch(Exception e){
              System.out.println("*************Error while reading File: " + e.getMessage());                      
          }
	  System.out.println("\n-----Total Processed  "+ iRecCount +" -----");   
	
	  	  
      // *************  Write Files Word Count 
	
	 	//Loop until all Words and Word Count  are written
	      System.out.println("-----Starting to  Write Words and Word Count-----" );
	 	try{
	 		Iterator<String> keySetIterator = hmWordList.keySet().iterator();
		 	while(keySetIterator.hasNext()){
		 			 	String key = keySetIterator.next();
		 	//outFileWC.write(key + "\t\t\t"+ hmWordList.get(key) + String.format("%n")); // was causing issues in notepad
		 			 	
		 	if (( (80-key.length() ) >0 ) && (key.length() <120 ) ){	 			 	
		 	outFileWC.write(key + sSpaceString.substring(0,80-key.length() )  + hmWordList.get(key) + String.format("%n")); // was causing issues in notepad
		 	}	
		 	else {
			 	outFileWC.write(key + " "  + hmWordList.get(key) + String.format("%n")); // was causing issues in notepad
			}
		 	
		  }
	 	 } catch (Exception e){
	              System.out.println("*************Error writing Words and Word Count: " + e.getMessage());                      
	          }
	 	
 	
	
	 // Close Files		 
	 try { 
		 System.out.println("-----Closing Files-----" );
		 inFile.close(); 
		 outFileWC.close();
		 outFileStats.close();
		// outFileCounts.close();
	    } catch(IOException e) { 
	        System.out.println("Error Closing File: " + e.getMessage()); 
	      } 
	 
	   
		System.out.println("-----------------------------------------------------\nDone"); 
		
 } //End Main
   
   
static int TokenizeLine(String sLine, int iRec){
	
	int iUnique=0;
	TreeMap <String, Integer > hmCheckDup =new TreeMap<String, Integer>(); 
	hmCheckDup.clear(); 
	
	String[] sTokens=sLine.split(" ");
	for (int i = 0; i < sTokens.length; i++) {
		Hashit(sTokens[i], hmCheckDup);
		iUnique = hmCheckDup.size();
		}
	System.out.println ("Record " + iRec + " Total " + sTokens.length + " word(s), Unique " +iUnique  );
	 return iUnique;
	 
} // Tokenize 


static void Hashit(String sLine, TreeMap<String,Integer> hmCheckDup){
	
	if( hmWordList.containsKey(sLine)) {
		hmWordList.put(sLine, hmWordList.get(sLine)+1 );
		}
	else {
		hmWordList.put(sLine, 1);
	}	
	
	// check record for duplicate word
	if( hmCheckDup.containsKey(sLine)) {
		hmCheckDup.put(sLine, hmCheckDup.get(sLine)+1 );
	}
	else {
		hmCheckDup.put(sLine, 1);
	}	
	
} // Hashit 




static float  MedianCalc(){
	float iMedian=0;
	int iCount=0;
		
	Collections.sort(iUniqueWordInTweets);
	
	iCount =iUniqueWordInTweets.size();
		
	if ( (iCount%2)==0) {
		iMedian=(float)( iUniqueWordInTweets.get(iCount/2)+ iUniqueWordInTweets.get((iCount/2)-1) )/ 2;
	}
	else {
		iMedian=iUniqueWordInTweets.get((iCount-1)/2);
	}
	
	
	
	return iMedian;
} // MedianCalc 


} //End Class WordCounter